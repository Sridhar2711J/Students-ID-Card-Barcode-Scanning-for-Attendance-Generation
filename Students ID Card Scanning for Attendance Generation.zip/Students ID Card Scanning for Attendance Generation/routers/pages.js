const express=require('express');
const router =express.Router(); //using route
const userController = require("../controllers/users");


//index page
router.get(["/index","/"],(req,res)=>{
    res.render("index");
    
});


//register page
router.get("/register",(req,res)=>{
    // if (req.users) {
    //     console.log(req.users);
    //     res.render("register",{users: req.users}); 
    //    }else{
    //     res.redirect("/index");
    //    }
    res.render("register");
});


//dashboar pagen
 router.get("/dashboard",userController.isLoggedIn,(req,res)=>{  
        res.render("dashboard",{user:req.user,TS:req.ts,ab:req.ab,ps:req.ps});    
               
    });



//barcode page
router.get("/barcode",userController.isLoggedIn,(req,res)=>{   
    res.render("barcode",{user:req.user});
});
router.post("/barcode",userController.barcode);


//students page
router.get("/students",userController.students,(req,res)=>{ 
    res.render("students",{user:req.user,result:req.result}); 
});
router.post("/students",userController.serachbar);


// addstudents
router.get("/addstudent",userController.addstudent);
router.post("/addstudent",userController.submit);
//editstudent
router.get("/editstudent/:SNO",userController.editstudent);
router.post("/editstudent/:SNO",userController.edit);
//deletestudent
router.get("/deletestudent/:SNO",userController.deletestudent);



//Attendence page
router.get("/attendence",userController.attendence,(req,res)=>{
    res.render("attendence",{user:req.user,table:req.tab,result:req.result});   
  });
  
router.post("/attendence",userController.serachbar_Attendence);

//alert page
router.get("/alert",userController.alert,(req,res)=>{
    res.render("alert",{Name:req.result});
    
})
router.get("/alertstudents/:SNO",userController.alertstudents);

//barcode generate

router.get("/barcodeGenerate",(req,res)=>{
    res.render("barcodeGenerate");
});

//studentInfo
router.get("/studentInfo",(req,res)=>{
    res.render("studentInfo");
});

router.post("/studentInfo",userController.studentInfo);



module.exports=router;