const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', // Replace with your SMTP host
    port: 465, // or 587, depending on your SMTP configuration
    secure: true, // true for 465, false for 587
    auth: {
        user: 'jayaramansridhar27@gmail.com',
        pass: 'hwqqskhnxxfmbcbz',
    },
    tls: {
        rejectUnauthorized: false // Disable certificate validation (not secure)
    }
});

transporter.sendMail({
    from: 'jayaramansridhar27@gmail.com',
    to: 'jayaramansridhar27@gmail.com',
    subject: 'Test Email',
    text: 'This is a test email'
}).then(info => {
    console.log('Message sent: %s', info.messageId);
}).catch(error => {
    console.log('Error: ', error);
});
