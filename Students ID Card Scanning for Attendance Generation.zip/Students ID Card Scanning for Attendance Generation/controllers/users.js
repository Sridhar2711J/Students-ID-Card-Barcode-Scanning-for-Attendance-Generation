const mysql=require("mysql");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const {promisify}=require("util");
const { log, error, count } = require("console");
const { scheduler } = require("timers/promises");




const db=mysql.createConnection({
    host:process.env.DATABASE_HOST,
    user:process.env.DATABASE_USER,
    password:process.env.DATABASE_PASS,
    database:process.env.DATABASE,
});


//Current Date
function formatDate() {
    const now = new Date();

    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = now.getFullYear();

    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';

    // Convert hours to 12-hour format
    hours = hours % 12;
    hours = hours ? String(hours).padStart(2, '0') : '12'; // The hour '0' should be '12'

    return `${day}${month}${year}`;
  }

//login
exports.index=async(req,res)=>{
   try{

    const {email,password}=req.body;
    if(!email || !password ){
        return res.status(400).render('index',{msg:"Please Enter Your Email & Password"});
    }
       
    db.query('select * from user where email=?',[email],async(error,result)=>{
             
             
             if(result.length<=0) {
                return res.status(401).render('index',{msg:"Email or Password Incorret"});
             } 
             
             else{
                if(password!=result[0].pass){
                    return res.status(401).render('index',{msg:"Email or Password Incorret"});
                }

                else{   
                      const id=result[0].ID;
                      const token=jwt.sign({id: id},process.env.JWT_SECRET,{
                      expiresIn:process.env.JWT_EXPIRES_IN,
                     });
                    // console.log(token);
                    const cookieOptions={
                    expires:new Date(Date.now()+process.env.JWT_COOKIE_EXPIRES*24*60*60*1000),
                  //  httpOnly:true,
                    };
                    res.cookie("user",token,cookieOptions);
                    res.status(200).redirect("/dashboard");
                    
 
                    function formatDate() {
                        const now = new Date();
                  
                        const day = String(now.getDate()).padStart(2, '0');
                        const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
                        const year = now.getFullYear();
                  
                        let hours = now.getHours();
                        const minutes = String(now.getMinutes()).padStart(2, '0');
                        const ampm = hours >= 12 ? 'PM' : 'AM';
                  
                        // Convert hours to 12-hour format
                        hours = hours % 12;
                        hours = hours ? String(hours).padStart(2, '0') : '12'; // The hour '0' should be '12'
                  
                        return `${day}${month}${year}`;
                      }
                  
                    //  Display the current date and next date 
                      const targetData="01.01.2025";
                      const currentData="01.01.2025";
                      
                      
                      var count=0;  
                      if(targetData<=currentData){              
                        const column_name=`d${formatDate()}`;    
                        const query=`alter table attendence add column ${column_name} varchar(50)`;
              
                        db.query(query,(err,result)=>{
                            
                        });
            
                        const value="Absent";
            
                        const cc=`UPDATE attendence SET ${mysql.escapeId(column_name)} = ${mysql.escape(value)}`;
            
                        db.query(cc,(err,result)=>{
            
                                        
            
                            if(err){
                                console.log(err);
                                
                            }
                            else{
                                console.log("success table create");      
                            }
                           });
                           count++;
                        }                    


                }

             }
    });

   }
   catch(error){
    console.log(error);
   }
};


//get value an showing the page and accout creating
exports.register=(req,res)=>{
    /* console.log("form submitted");
       res.send("form submit");
       console.log(req.body);
       const name=req.body.name;
       const staffid=req.body.staffid;
       const email=req.body.email;
       const password=req.body.password;
       const confim_password=req.body.confim_password;
       console.log(password);
    */
    const {name,staffid,email,password,confim_password}=req.body;
      
    db.query('select email from user where email=?',[email],async(error,result)=>{
        
        if(error){
            console.log(error);   
        }
        if(result.length>0){
            //check already used email
            return res.render('register',{msg:'Email id already used',msg_type:"error"});
        }
        //check password and confim_password match
        else if(password!==confim_password){
            return res.render('register',{msg:'Password do not match',msg_type:"error"});
        }
        
    //encryted password
    // let hashedPassword = await bcrypt.hash(password,8);
        
        db.query("insert into user set ?",{name:name,staffid:staffid,email:email,pass:password},(error,result)=>{
            if(error){
                console.log(error);    
            }
            else{
                console.log(result);
                return res.render('register',{msg:'Staff Registraion Success',msg_type:"good"});
            }
        });
        
     });
     
 };
 

//login cookies with dashboard controller
exports.isLoggedIn = async(req,res,next)=>{
      // console.log(req.cookies);
      if(req.cookies.user){
        try{
            const decode=await promisify(jwt.verify)(req.cookies.user,process.env.JWT_SECRET);
            // console.log(decode);
             db.query('select * from user where id=?',[decode.id],(error,result)=>{
               
                if(error){
                    console.log(error);     
                }

                else{
                    req.user=result[0].name;
                    
                    db.query("select count(*) AS ts from student",(error,result)=>{

                        if(error){
                            console.log(error); 
                            next()
                        }

                        else{
                            req.ts=result[0].ts;
                            
                             const query=`select COUNT(*) AS count from attendence where d${formatDate()} ='Absent';`;
                             db.query(query,(err,result)=>{
                                  if(err){
                                    console.log(err);  
                                  }
                                  else{
                                    req.ab=result[0].count;
                                    const query=`select COUNT(*) AS count from attendence where d${formatDate()} ='Present';`;
                                    db.query(query,(err,result)=>{
                                        if(err){
                                            console.log(err);
                                            
                                        }
                                        else{
                                          req.ps=result[0].count;
                                          return next(); 
                                        }

                                    });

                                   
                                  }
                             }

                             )
                        }
                    });

                }
           
        });

        }


        catch(error){
            console.log(error);
        };

      }


      else{
        next();
      }    
 };


//logout
 exports.logout = async (req,res)=>{
    res.cookie("login","logout",{
        expires: new Date(Date.now() + 2 * 1000),
        httpOnly:true,
    });
    res.status(200).redirect("/");
 };


//barcode scanning
exports.barcode=async(req,res)=>{   
    const rollno =req.body.rollno;  
    const SNO=2;
    db.query("select * from student where RollNo=?",[rollno],(err,result)=>{

        const column_name=`d${formatDate()}`;
        const value="Present";
    
        const cc=`UPDATE attendence SET ${mysql.escapeId(column_name)} = ${mysql.escape(value)} where RollNo = ${mysql.escape(rollno)}`;
            
                        db.query(cc,(err,result)=>{
                            
                        });
            
                                                           
        if(err){
            console.log(err);  
        }

        else{
                
            if(result.length==0){
                const nodata="The Data not found !";
                res.render("barcode",{nodata});
                
            }
            
            else{

                var present="SELECT RollNo,(d03062025 = 'Present') AS PresentCount FROM attendence WHERE RollNo = ?;";
                    db.query(present,[rollno],(err,res)=>{
                        
                    // console.log(res[0].PresentCount);

                    var percentage=((res[0].PresentCount/1)*100).toFixed(0);


                    // console.log(percentage);

                    const sql = `UPDATE attendence SET Percentage = ? WHERE RollNo = ?`;

                    db.query(sql, [percentage, rollno], (err, result) => {
                             if (err) throw err;
                             console.log("Updated successfully:", result.affectedRows);
                        });
                    
                           
                    });
               
                
                res.render("barcode",{result});
            }
              
        }

    });
   
}


 //students details
exports.students=async(req,res,next)=>{


    if (req.cookies.user){
        try {
            const decode=await promisify(jwt.verify)(req.cookies.user,process.env.JWT_SECRET);
            db.query('select * from user where id=?',[decode.id],(error,res)=>{

                req.user=res[0].name;
                db.query("select * from student",(error,result)=>{
                   
                req.result=result;
                    
                 return next()
                });
     
         });


        }
        catch{
            console.log("error");
             next()
        }
        
    }
    else{
        next()
    }

    
    
};


//add students
exports.addstudent=(req,res)=>{
    res.render("addstudent");
};


// add sutdentssubmit
exports.submit=(req,res)=>{
const {Name,RollNo,Year,Department,Email,Mobile,CGPA,TotalPaper,ArrerPaper,BloodGroup,Address}=req.body;
db.query("insert into student (Name,RollNo,Year,Department,Email,Mobile,CGPA,TotalPaper,ArrerPaper,BloodGroup,Address) values (?,?,?,?,?,?,?,?,?,?,?)",[Name,RollNo,Year,Department,Email,Mobile,CGPA,TotalPaper,ArrerPaper,BloodGroup,Address],(err,result)=>{
  
    res.render("addstudent",{msg:"Add Student Successfully"});
    // if(error){
    //     console.log(err);
        
    // }
    // else{
    //     res.render("addstudent");
    //     // res.render("addstudent",{msg:"Success"});
    // }
});
db.query("insert into attendence (Name,RollNo,Year,Department) values (?,?,?,?)",[Name,RollNo,Year,Department],(err,result)=>{
    
});
  
};


//edit students 
exports.editstudent=(req,res)=>{
     let SNO=req.params.SNO;
     db.query("select * from student where SNO=?",[SNO],(error,result)=>{

        if(error){
            console.log(error);   
        }

        else{
            res.render("editstudent",{result});
        }
    });
    
};
exports.edit=(req,res)=>{
    let SNO=req.params.SNO;
    const {Name,RollNo,Year,Department,Email,Mobile,CGPA,TotalPaper,ArrerPaper,BloodGroup,Address}=req.body;
    db.query("update student set Name=?,RollNo=?,Year=?,Department=?,Email=?,Mobile=?,CGPA=?,TotalPaper=?,ArrerPaper=?,BloodGroup=?,Address=? where SNO=?",[Name,RollNo,Year,Department,Email,Mobile,CGPA,TotalPaper,ArrerPaper,BloodGroup,Address,SNO],(err,result)=>{
             if(err){
                console.log(err);
             }
             else{

             
    let SNO=req.params.SNO;
    db.query("select * from student where SNO=?",[SNO],(err,result)=>{

        if(err){
            console.log(err);  
        }

        else{
            res.render("editstudent",{result,msg:"Update Success"});
        }

    });
};
    });
    };


//delete student
exports.deletestudent=(req,res)=>{
   
    let SNO=req.params.SNO;
    db.query("delete from student where SNO=?",[SNO],(err,result)=>{
        
    
        res.redirect("/students");

    });

    db.query("delete from attendence where SNO=?",[SNO],(err,result)=>{
        
    //   res.redirect("/students");

    });

};


//totalstudents 
exports.totalstudents=(req,res)=>{
    db.query("select count(*) AS ts from student",(error,result)=>{
        if(error){
            console.log(error); 
            
        }
        else{
              const ts=result[0].ts;
              res.render("dashboard",{ts});
              console.log(ts);  
        }
    });
};


//serachbar
exports.serachbar=(req,res)=>{
    const serachValue =req.body.serachValue;  //user input value
     if(!serachValue){
        const noData = 'Pls Enter the Name or RollNo'
        res.render("students",{noData});
     }
     else{
       db.query("select * from student where Name=?",[serachValue],(error,result)=>{
             
        if(result.length==0){
            db.query("select * from student where RollNo=?",[serachValue],(error,result)=>{
                  if(result.length==0){
                    const dataNot = "Data not Found";
                    res.render("students",{dataNot})                   
                  }
                  else{
                    res.render("students",{result})
                  }
            });
        }
        else{
            res.render("students",{result});
        }     
       }) ;
     }
     
};

//Attendence sheet
exports.attendence=async(req,res,next)=>{
    
          const query="SELECT column_name from information_schema.columns where  table_name = 'attendence' and table_schema = 'login' order by ordinal_position;";

          if (req.cookies.user){
            try {
                const decode=await promisify(jwt.verify)(req.cookies.user,process.env.JWT_SECRET);
                db.query('select * from user where id=?',[decode.id],(error,res)=>{
    
                    req.user=res[0].name;  //user name
//column creating and result showing     
                    db.query(query,(err,tab)=>{
                        if(err){
                            console.log(err);   
                        }
                        else{
                            
                            req.tab=tab;  //table column name
                            db.query("select * from attendence",(error,result)=>{
               
                                if(error){
                                    console.log(error);   
                                }
                        
                                else{         

                                    req.result=result;  //table showing
                                    return next()
                                    // res.render("attendence",{result,table});       
                                }
                        
                            });
                    
                        }
                  });
        
         
             });
    
    
            }
            catch{
                console.log("error");
                 next()
            }
            
        }
        else{
            next()
        }
                    
};
                     


//serachbar in attendence
exports.serachbar_Attendence=(req,res)=>{
    const serachValue =req.body.serachValue;  
    const query="SELECT column_name from information_schema.columns where  table_name = 'attendence' and table_schema ='login' order by ordinal_position;";
    
     if(!serachValue){
        const noData = 'Pls Enter the Name or RollNo'
        res.render("attendence",{noData});
     }
     else{
       
            db.query("select * from attendence where RollNo=?",[serachValue],(error,result)=>{
                if(result.length==0){
                    const dataNot = "Data not Found";
                    res.render("attendence",{dataNot})                   
                  }
                  else{
                    db.query(query,(err,table)=>{    
                        res.render("attendence",{result,table})
                    });
                  }
            });
        }
       };

//alert message
exports.alert=(req,res)=>{
    const query=`select Name,SNO,RollNo from attendence where d${formatDate()} ='Absent';`;
     db.query(query,(err,result)=>{
        
        if(err){
            console.log(err);
            
        }
        else{
            res.render("alert",{result})      
        }
     });
};

exports.alertstudents=async(req,res)=>{
    let SNO=req.params.SNO;

    db.query("select Email,Name from student where SNO=?",[SNO],(err,result)=>{
       if(err){
        console.log(err);
       }
       else{
        console.log(result[0].Name)
        console.log(result[0].Email);
        const Name=result[0].Name;
        const email=result[0].Email;
       //email send 

    const nodemailer = require('nodemailer');

    let transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', // Replace with your SMTP host
    port: 465, // or 587, depending on your SMTP configuration
    secure: true, // true for 465, false for 587
    auth: {
        user: 'sriet2711@gmail.com',
        pass: 'dzcelpblrgukbkde',
    },
    tls: {
        rejectUnauthorized: false // Disable certificate validation (not secure)
    }
});

transporter.sendMail({
    from: 'sriet2711@gmail.com',
    to: email,
    subject: 'Attendance Alert: You were absent today',
    text:  'Dear ['+ Name +'],This is a reminder that you were marked absent today in your class.\nPlease make sure to catch up on any missed lessons and assignments. \nIf you have any questions or need assistance, feel free to reach out to your instructor.\nBest regards,\n[Sri Ranganathar Insitute of Engineering and Technology]\n Coimbatore - 641 110'
}).then(info => {
    console.log('Message sent: %s', info.messageId);
}).catch(error => {
    console.log('Error: ', error);
});


        
       }
    });
  
  res.redirect("/alert");
};




//barcode generate

exports.barcodeGenerate=(req,res)=>{
    res.render("barcodeGenerate");
}


//studentInfo

// exports.studentInfo=(req,res)=>{;  
//         const rollno =req.body.rollno;  
//         const SNO=2;
//         db.query("select * from student where RollNo=?",[rollno],(err,result)=>{
                               
//             if(err){
//                 console.log(err);  
//             }
    
//             else{
                    
//                 if(result.length==0){
//                     const nodata="The Data not found !";
//                     res.render("studentInfo",{nodata});       
//                 }
                
//                 else{   

//                     db.query("select * from attendence where RollNo=?",[rollno],(err,res)=>{
                                
//                         var present;
//                         req.present=res[0].Percentage
                         
//                     });
//                     res.render("studentInfo",{result});       

//                 }
                  
//             }
    
//         });
    
// }

exports.studentInfo = (req, res) => {
    const rollno = req.body.rollno;
    
    db.query("SELECT * FROM student WHERE RollNo=?", [rollno], (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).send("Database error");
        }

        if (result.length == 0) {
            const nodata = "The Data not found!";
            return res.render("studentInfo", { nodata });
        }

        // ✅ Run the second query only if the student exists
        db.query("SELECT * FROM attendence WHERE RollNo=?", [rollno], (err, attendanceResult) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database error");
            }

            var present = attendanceResult.length > 0 ? attendanceResult[0].Percentage : "No Data";
            
            //console.log(present);
            // ✅ Now, render after both queries finish
            res.render("studentInfo", { result, present });
        });
    });
};


