const express=require('express');
const exphbs=require("express-handlebars");
const bodyParser=require("body-parser");
const mysql=require("mysql");
const path=require("path");
const hbs=require("hbs");
const doenv=require("dotenv");
const cookieParser=require("cookie-parser");


// app.js
const app=express();

//port number 
app.listen(5000,()=>{
    console.log("Server Started @ Port 5000");
})

//env file handling    
doenv.config({
    path:"./.env",
})

//my sql connection
const db=mysql.createConnection({
    host:process.env.DATABASE_HOST,
    user:process.env.DATABASE_USER,
    password:process.env.DATABASE_PASS,
    database:process.env.DATABASE,
});

db.connect((err)=>{
    if(err){
        console.log(err);     
    }
    else{
        console.log("mysql success");    
    }
});


app.use(cookieParser());

//the form value get url encoding
app.use(express.urlencoded({extended:false}));
//app.use(express.json());

//location delacation or static files
const location=path.join(__dirname,"./public");
app.use(express.static(location));

//partials path
const partialsPath = path.join(__dirname,"./views/partials");
hbs.registerPartials(partialsPath);

//it using for the hbs data can be moving the partials hbs
// hbs.registerHelper('toUpperCase',(str) => str.toUpperCase());

//view engine or template engine
// const handlebars =  exphbs.create({extname:".hbs"});
// app.engine('hbs',handlebars.engine);
app.set("view engine", "hbs");

//  index page
//  app.get("/",(req,res)=>{
//     res.render("index");
//  });

// //dashboar page
// app.get("/dashboard",(req,res)=>{
//     // res.send("<h1>Sri</h1>");
//     res.render("dashboard");
// });

//routes handing
app.use('/',require('./routers/pages'));
app.use('/auth',require('./routers/auth'));


