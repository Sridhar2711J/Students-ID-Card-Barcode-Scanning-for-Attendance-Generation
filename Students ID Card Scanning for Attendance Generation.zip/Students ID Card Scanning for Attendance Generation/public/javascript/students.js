const MenuBtn=document.getElementById('menu-btn');
const MenuBar=document.getElementById('menu-bar');
const Pages=document.getElementById('pages');
const Logout=document.getElementById('logout');
const UserBtn=document.getElementById('user-btn');
const Cancel=document.getElementById('cancel');
const Overlayer=document.getElementById('overlayer');
const Remove=document.getElementById('remove');



let count=1;
function remove(){
    if( count == 1){
        MenuBar.style.position="absolute";
        MenuBar.style.transform="translateX(-1000px)";
        Pages.style.width="100%";
        count ++;
    }  
   else{
        MenuBar.style.position="relative";
        MenuBar.style.transform="translateX(0px)";
        Pages.style.width="80%";
        count=1;
   }
    
};

function logoutpage(){
    Logout.style.transform="translateY(0px)";
};

function cancel(){
    Logout.style.transform="translateY(-500px)";
};


//add students
function AddStudent(){
    Overlayer.style.display="block";
}

function overlayer(){
    Overlayer.style.display="none";
}