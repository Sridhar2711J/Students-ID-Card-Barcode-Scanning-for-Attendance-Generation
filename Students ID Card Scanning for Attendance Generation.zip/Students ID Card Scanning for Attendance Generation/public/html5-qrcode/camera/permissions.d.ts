export declare class CameraPermissions {
    static hasPermissions(): Promise<boolean>;
}
