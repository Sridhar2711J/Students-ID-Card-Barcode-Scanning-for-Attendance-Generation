export interface ExperimentalFeaturesConfig {
    useBarCodeDetectorIfSupported?: boolean | undefined;
}
